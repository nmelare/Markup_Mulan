//: [Anterior](@previous)

/*:
 ## Uso de chaves:
 Dê espaço antes e depois das chaves, pulando linha antes de fechar a funçāo.
 */
/*:
 **- Fazer:**
 */
 if isValid && list.count == 0 {
    ...

 }  else if isValid {
    ...
    
 } else {
    ...

 }

/*:
 **- Não fazer:**
 */
 if isValid && list.count == 0 {
 ...}
 else if isValid {
 ...}else {
...}
//: [Próximo](@next)
