//: [Anterior](@previous)

/*:
## Comentários:
*/
/*:
**- Fazer:**
 
 Explique com comentários para que serve sua função, parâmetro ou retorno servem, mas evitem o excesso de comentários.
*/

/*:
**- Nāo fazer:**
 
 // soma a + b um ao outro
 soma = a + b
*/
