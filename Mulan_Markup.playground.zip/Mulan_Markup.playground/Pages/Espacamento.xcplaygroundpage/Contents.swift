//: [Anterior](@previous)
/*:
 ## Espaçamento em declaração de variáveis:
 Dê espaço somente antes de declarar o tipo da variável.
 */
/*:
 **- Fazer:**
 */
 let name: String
/*:
 **- Não fazer:**
 */
 let name:String
 
 let name : String
 
 let name :String

//: [Próximo](@next)
