//: [Anterior](@previous)

/*:
## Convenções de nomes:
Sempre utilizar camelCase, nunca misturar com outro estilo de nomear.
*/
/*:
**- Fazer:**
*/
let myConstant: CGFloat
class CustomClass { ... }

/*:
**- Nāo fazer:**
*/
let MyConstant: CGFloat
var my_variable: CGFlat
class customClass { ... }
class custom_class { ... }

//: [Próximo](@next)
