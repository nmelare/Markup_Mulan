//: [Anterior](@previous)

/*:
## Conformidade de Protocolo:
Use extensões da classe para utilizar suas heranças específicas.
*/
/*:
**- Fazer:**
*/
final class CustomClass: UIViewController { ... }
extension CustomClass: UITableViewDataSource { ... }
extension CustomClass: UITableViewDelegate { ... }

/*:
**- Não fazer:**
*/
class CustomClass: UIViewController, UITableViewDataSource, UITableViewDelegate { ... }


//: [Próximo](@next)
