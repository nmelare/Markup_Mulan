/*:
 # Boas práticas para programação em grupo
 ### O manual definitivo da boa prática em Swift

*/
/*:
 
 ## Conteúdo:
 
 1. [Espaçamento em declaração de variáveis](Espacamento)
 2. [Uso de chaves](Chaves)
 3. [Conformidade de Protocolo](Protocolo)
 4. [Convenções de nomes](Nomes)
 5. [Comentários](Comentarios)
 
 */
//: [Próximo](@next)
